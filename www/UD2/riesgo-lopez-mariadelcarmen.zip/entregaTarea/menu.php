<!--apartado 2, tarea UD2, código html para generar el menú de opciones del formulario nuevaForm.php-->
<nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
<div class="position-sticky">
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link" href="index.php" alt="Enlace a menú principal">
               OPCIONES DISPONIBLES
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="index.php" alt="Enlace a menú principal">
                Home
            </a>
        </li>
        <li>
            <a class="nav-link" href="listaTareas.php" alt="Enlace a listar tareas">
                Mis tareas
            </a>
        </li>
        <li>
            <a class="nav-link" href="nuevaForm.php" alt="Enlace a menú principal">
                Nueva tarea
            </a>
        </li>
    </ul>
</div>
</nav>

    
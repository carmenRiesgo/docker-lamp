
<!--Apartado 1 tarea UD02-->
<!DOCTYPE>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>><?php echo "UD02 - CARMEN RIESGO"?></title>
    </head>
    <body>
        <header class="bg-primary text-white text-center py-3">
        <h1><?php echo "UD02 - CARMEN RIESGO";?></h1>   
        <h2><?php echo "Tarea UD02 - Creación Aplicación Básica con PHP";?></h2> 
        <br>
    </body>
</html>
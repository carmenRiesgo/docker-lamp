<header class="bg-primary text-white text-center py-3">
    <h1>Gestión Base de Datos "TAREAS"</h1>
    <p>Solución tarea unidad 3 de DWCS</p>
</header>
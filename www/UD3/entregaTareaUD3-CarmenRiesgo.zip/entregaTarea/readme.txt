En esta tarea, sólo está diferenciado la carpeta conexiones donde se crean las funciones necesarias para conectar en modo PDO (fichero PDO.php) o en modo Mysqli(fichero mysqli.php).
Por otra parte, en el fichero funcionesDB.php están guardadas todas las demás funciones necesarias para utilizar en la aplicación, llamadas desde cualquiera de los demás ficheros.


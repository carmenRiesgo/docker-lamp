<div class="container justify-content-between mb-2">
    <!--<a class="btn btn-success btn-sm" href="index.php" role="button">Volver</a>-->
    <input class="btn btn-primary btn-sm"  type="button" onclick="history.back()" name="volver atrás" value="volver">
</div>
<nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
    <div class="position-sticky">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    Home
                </a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="init.php" alt="Enlace a menú principal">
                Inicializar (mysqli)
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="usuarios.php" alt="Enlace a menú principal">
                Lista de Usuarios (PDO)
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="nuevoUsuarioForm.php" alt="Enlace a menú principal">
                Nuevo Usuario (PDO)
            </a>
        </li>
        <li>
        
            <li class="nav-item">
                <a class="nav-link" href="nuevaForm.php">
                    Nueva tarea
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="tareas.php">
                    Lista de tareas
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="buscaTareas.php">
                    Buscar tarea
                </a>
            </li>
        </ul>
    </div>
</nav>
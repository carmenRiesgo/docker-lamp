<footer class="bg-primary text-white text-center py-3">
<?php
            $fecha=date('j/m/Y');
               echo "<span>&copy</span> 2024-2025 DIWCS - Carmen Riesgo Lopez.  $fecha";
        ?>
</footer>